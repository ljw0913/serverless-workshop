README

1. Run "npm install" to install dependencies
2. Run "npm start" to start the web-server
3. Open http://127.0.0.1:8100 to see the website in your browser
