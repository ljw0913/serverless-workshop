var configConstants = {
    auth0: {
        domain: 'act-sfb-ljw.auth0.com',
        clientId: '_3_n-bdSadOkvtQELKGnQWzUb6Tj9AsJ'
    },
    apiBaseUrl: 'https://lin680wh5j.execute-api.us-east-1.amazonaws.com/dev'
};
